from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

id=input("Enter ID where you want to update city & department: ")
data=coll.find_one({"_id":id})

if data:
    new_city=input("Enter new city: ")
    new_dept=input('Enter new department: ')
    coll.find_one_and_update({"_id":id},{"$set": {"city":new_city}})
    coll.find_one_and_update({"_id":id},{"$set": {"dept":new_dept}})
    print("-"*80)
    print("City & Department updated successfully...")
    print(coll.find_one({"_id":id}))
if not data:
    print('Worker not found in the database')