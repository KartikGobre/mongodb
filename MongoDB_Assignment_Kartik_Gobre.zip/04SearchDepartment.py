from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

dept=input('Enter Department: ')
search=coll.find({'dept':dept})
for doc in search:
    #print(item)
    print('%s | %s | %s | %s | %s | %s | %d | %s' %(doc['_id'],doc['empnm'],doc['dept'],doc['post'],doc['city'],doc['salary'],doc['mobile'],doc['email']))
