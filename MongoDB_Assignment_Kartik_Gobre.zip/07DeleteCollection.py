from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]
coll2=db["exworkers"]

id=input('Enter ID to delete: ')
data=coll.find_one_and_delete({"_id":id})

if data:
   print(data)
   print("Account deleted")
   coll2.insert_one(data)
   print("Data which deleted from workers coll. inserted to Exworkers colletion")
else:
    print("Worker not found in the database")
