from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

id=input("Enter ID where you want to update salary: ")
data=coll.find_one({"_id":id})

if data:
    sal=input("Salary to be update: ")
    coll.find_one_and_update({"_id":id},{"$set": {"salary":sal}})
    print("-"*80)
    print("Salary updated..")
    print(coll.find_one({"_id":id}))
if not data:
    print("Worker not found in the database")