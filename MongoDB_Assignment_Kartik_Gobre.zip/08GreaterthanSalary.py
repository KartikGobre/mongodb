from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

sal=float(input("Enter Salary: "))
data=coll.find({"salary": {"$gt": sal}})
for rec in data:
    print(rec)