from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

id=int(input("Enter Workers ID: "))
empnm=input("Enter Employee Name: ")
dept=input("Enter Department Name: ")
post=input("Enter Post Name: ")
city=input("Enter City Name: ")
salary=float(input("Enter Salary: "))
mobile=int(input("Enter Mobile No: "))
email=input("Enter Email ID: ")

dic={}
dic["_id"]=id
dic["empnm"]=empnm
dic["dept"]=dept
dic["post"]=post
dic["city"]=city
dic["salary"]=salary
dic["mobile"]=mobile
dic["email"]=email

coll.insert_one(dic)
print("New worker info inserted to collection")