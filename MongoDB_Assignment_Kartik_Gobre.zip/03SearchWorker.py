from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["office"]
coll=db["workers"]

try:
    id=int(input("Enter ID to be search: ")) 
    search=coll.find_one({'_id':id})
    print(search)

except:
    print("Workers ID not found")